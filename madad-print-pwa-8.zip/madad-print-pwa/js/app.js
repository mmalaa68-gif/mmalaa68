// ========== مطبعة المداد - نظام الإدارة الشامل v2 ==========

const KEYS = {
  orders: 'madad_orders_v2',
  inventory: 'madad_inventory_v2',
  settings: 'madad_settings_v2',
  theme: 'madad_theme'
};

const STATUS_FLOW = ['new', 'design', 'printing', 'finishing', 'ready', 'delivered'];
const STATUS_LABELS = {
  new: 'جديد',
  design: 'تصميم',
  printing: 'طباعة',
  finishing: 'تشطيب',
  ready: 'جاهز',
  delivered: 'تم التسليم',
  cancelled: 'ملغي'
};

// سعر الألف ورقة الافتراضي (جنيه سوداني) حسب نوع الورق
const DEFAULT_PRICE_PER_1000 = {
  'أوفست': 15000,
  'كوشيه لامع': 35000,
  'كوشيه مطفي': 32000,
  'نسخ': 12000,
  'دوبلكس': 25000,
  'كرتون': 45000
};
// هامش الربح الافتراضي على تكلفة الورق (1.5 = 50% ربح)
const DEFAULT_MARKUP = 1.5;

function getOrders() {
  try { return JSON.parse(localStorage.getItem(KEYS.orders)) || []; } catch { return []; }
}
function saveOrders(o) { localStorage.setItem(KEYS.orders, JSON.stringify(o)); }

function getInventory() {
  try { return JSON.parse(localStorage.getItem(KEYS.inventory)) || []; } catch { return []; }
}
function saveInventory(i) { localStorage.setItem(KEYS.inventory, JSON.stringify(i)); }

function getSettings() {
  try {
    return JSON.parse(localStorage.getItem(KEYS.settings)) || {
      company: 'مطبعة المداد', phone: '', address: '', pricePer1000: DEFAULT_PRICE_PER_1000, markup: DEFAULT_MARKUP
    };
  } catch {
    return { company: 'مطبعة المداد', phone: '', address: '', pricePer1000: DEFAULT_PRICE_PER_1000, markup: DEFAULT_MARKUP };
  }
}
function saveSettingsData(s) { localStorage.setItem(KEYS.settings, JSON.stringify(s)); }

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function formatMoney(n) {
  return new Intl.NumberFormat('ar-SD').format(Math.round(n || 0)) + ' ج.س';
}

function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('ar-SD', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatDateTime(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('ar-SD', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function isToday(d) {
  const t = new Date();
  const x = new Date(d);
  return x.getFullYear() === t.getFullYear() && x.getMonth() === t.getMonth() && x.getDate() === t.getDate();
}

function isOverdue(order) {
  if (!order.dueDate || ['delivered', 'cancelled'].includes(order.status)) return false;
  const due = new Date(order.dueDate);
  due.setHours(23, 59, 59);
  return due < new Date();
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  const page = document.getElementById('page-' + pageId);
  if (page) page.classList.remove('hidden');

  document.querySelectorAll('.nav-btn, .bottom-nav-btn, .sidebar-link').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.page === pageId);
  });

  if (pageId === 'dashboard') updateDashboard();
  if (pageId === 'orders') renderOrders();
  if (pageId === 'inventory') renderInventory();
  if (pageId === 'customers') renderCustomers();
  if (pageId === 'reports') updateReports();
  if (pageId === 'settings') loadSettingsUI();
  if (pageId === 'new-order') {
    populateCustomersDatalist();
    calcSuggestedPrice();
  }
}

function showToast(msg, duration = 2500) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

function toggleDarkMode() {
  document.documentElement.classList.toggle('dark');
  const isDark = document.documentElement.classList.contains('dark');
  localStorage.setItem(KEYS.theme, isDark ? 'dark' : 'light');
  const label = document.getElementById('theme-label');
  if (label) label.textContent = isDark ? 'الوضع النهاري' : 'الوضع الليلي';
}

function initTheme() {
  if (localStorage.getItem(KEYS.theme) === 'dark') {
    document.documentElement.classList.add('dark');
    const label = document.getElementById('theme-label');
    if (label) label.textContent = 'الوضع النهاري';
  }
}

function calcOrderTotals() {
  const notebooks = parseInt(document.getElementById('notebooks')?.value) || 0;
  const sheetsPerBook = parseInt(document.querySelector('input[name="sheets-per-book"]:checked')?.value) || 100;
  const pricePer1000 = parseFloat(document.getElementById('price-per-1000')?.value) || 0;
  const paperType = document.querySelector('input[name="paper-type"]:checked')?.value;
  const settings = getSettings();

  // Auto-fill price per 1000 from defaults if empty / not manual
  const p1000Input = document.getElementById('price-per-1000');
  if (paperType && p1000Input && !p1000Input.dataset.manual) {
    const defaults = settings.pricePer1000 || DEFAULT_PRICE_PER_1000;
    if (defaults[paperType]) {
      p1000Input.value = defaults[paperType];
    }
  }
  const finalPricePer1000 = parseFloat(document.getElementById('price-per-1000')?.value) || 0;

  const totalSheets = notebooks * sheetsPerBook;
  const paperCost = (totalSheets / 1000) * finalPricePer1000;

  const markup = settings.markup || DEFAULT_MARKUP;
  const suggestedSell = Math.round(paperCost * markup);

  // Update display
  const sheetsEl = document.getElementById('calc-sheets');
  const costEl = document.getElementById('calc-paper-cost');
  const totalEl = document.getElementById('total-price');
  if (sheetsEl) sheetsEl.textContent = new Intl.NumberFormat('ar-SD').format(totalSheets) + ' ورقة';
  if (costEl) costEl.textContent = formatMoney(paperCost);

  const sellInput = document.getElementById('sell-price');
  if (sellInput && !sellInput.dataset.manual) {
    sellInput.value = suggestedSell || '';
  }
  const sellPrice = parseFloat(sellInput?.value) || suggestedSell || 0;
  if (totalEl) totalEl.textContent = formatMoney(sellPrice);

  return { totalSheets, paperCost, sellPrice, notebooks, sheetsPerBook };
}

function calcSuggestedPrice() { return calcOrderTotals(); }
function calcTotal() { return calcOrderTotals().sellPrice; }

let profitChart = null, paperChart = null, reportChart = null;

function updateDashboard() {
  const orders = getOrders();
  const inv = getInventory();
  const now = new Date();

  const h = now.getHours();
  const greetEl = document.getElementById('greeting');
  if (greetEl) greetEl.textContent = h < 12 ? 'صباح الخير' : h < 18 ? 'مساء الخير' : 'مساء الخير';
  const dateEl = document.getElementById('topbar-date');
  if (dateEl) dateEl.textContent = now.toLocaleDateString('ar-SD', { weekday: 'long', day: 'numeric', month: 'long' });

  const todayOrders = orders.filter(o => isToday(o.createdAt));
  const todayDelivered = orders.filter(o => o.status === 'delivered' && o.completedAt && isToday(o.completedAt));
  const todayProfit = todayDelivered.reduce((s, o) => s + (o.total || 0) - (o.paperCost || 0), 0);
  const inProgress = orders.filter(o => !['delivered', 'cancelled'].includes(o.status));
  const overdue = orders.filter(isOverdue);

  const todaySales = todayDelivered.reduce((s, o) => s + (o.total || 0), 0);
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  set('stat-today-profit', formatMoney(todayProfit));
  set('stat-today-orders', todayOrders.length);
  set('stat-in-progress', inProgress.length);
  set('stat-overdue', overdue.length);
  set('stat-completed', todayDelivered.length);
  set('stat-today-sales', formatMoney(todaySales));

  const alerts = [];
  if (overdue.length) alerts.push(`${overdue.length} طلب متأخر عن موعد التسليم`);
  const lowStock = inv.filter(i => i.qty <= i.minQty);
  if (lowStock.length) alerts.push(`${lowStock.length} صنف مخزون منخفض: ${lowStock.map(i => i.name).join('، ')}`);
  const ready = orders.filter(o => o.status === 'ready');
  if (ready.length) alerts.push(`${ready.length} طلب جاهز للتسليم`);

  const banner = document.getElementById('alert-banner');
  if (alerts.length) {
    banner.classList.remove('hidden');
    document.getElementById('alert-content').innerHTML = alerts.map(a => `<p class="text-sm text-amber-800 dark:text-amber-200">${a}</p>`).join('');
  } else {
    banner.classList.add('hidden');
  }

  const attention = [...overdue, ...ready, ...orders.filter(o => o.status === 'new')]
    .filter((o, i, arr) => arr.findIndex(x => x.id === o.id) === i)
    .slice(0, 6);

  const attEl = document.getElementById('attention-list');
  if (!attention.length) {
    attEl.innerHTML = '<div class="empty-state" style="padding:24px"><p class="text-caption">لا توجد طلبات تحتاج اهتماماً</p></div>';
  } else {
    attEl.innerHTML = attention.map(o => `
      <div class="px-4 py-3 flex justify-between items-center gap-2 hover:bg-slate-50 dark:hover:bg-dark-700 cursor-pointer" onclick="showPage('orders')">
        <div class="min-w-0">
          <p class="font-medium text-sm truncate">${o.customerName}</p>
          <p class="text-xs text-slate-500">${o.paperType} · ${o.paperSize} · ${STATUS_LABELS[o.status]}</p>
        </div>
        <div class="text-left shrink-0">
          ${isOverdue(o) ? '<span class="text-xs text-red-500 font-medium">متأخر</span>' : ''}
          ${o.status === 'ready' ? '<span class="text-xs text-emerald-600 font-medium">جاهز</span>' : ''}
          ${o.status === 'new' ? '<span class="text-xs text-blue-600 font-medium">جديد</span>' : ''}
        </div>
      </div>
    `).join('');
  }

  const invSum = document.getElementById('inventory-summary');
  if (!inv.length) {
    invSum.innerHTML = '<p class="text-caption" style="text-align:center;padding:16px 0">لم يتم إضافة مخزون بعد</p>';
  } else {
    invSum.innerHTML = inv.slice(0, 8).map(i => {
      const pct = i.minQty > 0 ? Math.min(100, Math.round((i.qty / (i.minQty * 3)) * 100)) : 100;
      const low = i.qty <= i.minQty;
      return `
        <div class="flex items-center gap-3">
          <div class="flex-1 min-w-0">
            <div class="flex justify-between text-xs mb-0.5">
              <span class="font-medium truncate ${low ? 'text-amber-600' : ''}">${i.name}</span>
              <span class="text-slate-500">${i.qty} ${i.unit}</span>
            </div>
            <div class="h-1.5 bg-slate-200 dark:bg-dark-700 rounded-full overflow-hidden">
              <div class="h-full rounded-full ${low ? 'bg-amber-500' : 'bg-emerald-500'}" style="width:${Math.max(5, pct)}%"></div>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  const thisMonth = orders.filter(o => {
    const d = new Date(o.createdAt);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const deliveredMonth = thisMonth.filter(o => o.status === 'delivered');
  const rev = deliveredMonth.reduce((s, o) => s + (o.total || 0), 0);
  const cost = deliveredMonth.reduce((s, o) => s + (o.paperCost || 0), 0);
  document.getElementById('month-revenue').textContent = formatMoney(rev);
  document.getElementById('month-cost').textContent = formatMoney(cost);
  document.getElementById('month-profit').textContent = formatMoney(rev - cost);
  document.getElementById('month-orders').textContent = thisMonth.length;

  renderDashboardCharts(orders);
  updateNotifBadge();
}

function renderDashboardCharts(orders) {
  const completed = orders.filter(o => o.status === 'delivered');
  const months = {};
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    months[key] = 0;
  }
  completed.forEach(o => {
    const d = new Date(o.completedAt || o.createdAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    if (months[key] !== undefined) months[key] += (o.total || 0) - (o.paperCost || 0);
  });
  const monthNames = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  const labels = Object.keys(months).map(k => monthNames[parseInt(k.split('-')[1]) - 1]);
  const data = Object.values(months);

  const ctx1 = document.getElementById('profitChart');
  if (profitChart) profitChart.destroy();
  profitChart = new Chart(ctx1, {
    type: 'bar',
    data: { labels, datasets: [{ data, backgroundColor: 'rgba(16,185,129,0.7)', borderRadius: 6 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { callback: v => new Intl.NumberFormat('ar-SD', { notation: 'compact' }).format(v) } } }
    }
  });

  const paperCounts = {};
  orders.forEach(o => { paperCounts[o.paperType] = (paperCounts[o.paperType] || 0) + 1; });
  const ctx2 = document.getElementById('paperChart');
  if (paperChart) paperChart.destroy();
  const pLabels = Object.keys(paperCounts);
  const pData = Object.values(paperCounts);
  const colors = ['#0ea5e9','#a855f7','#f59e0b','#ef4444','#10b981','#6366f1'];
  paperChart = new Chart(ctx2, {
    type: 'doughnut',
    data: {
      labels: pLabels.length ? pLabels : ['لا بيانات'],
      datasets: [{ data: pData.length ? pData : [1], backgroundColor: pData.length ? colors : ['#e2e8f0'], borderWidth: 0 }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom', labels: { font: { family: 'IBM Plex Sans Arabic', size: 11 }, padding: 12 } } }
    }
  });
}

function renderOrders() {
  let orders = getOrders();
  if (typeof currentOrderFilter !== 'undefined' && currentOrderFilter !== 'all') {
    orders = orders.filter(o => o.status === currentOrderFilter);
  }
  orders = orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const list = document.getElementById('orders-list');
  if (!list) return;

  if (!orders.length) {
    list.innerHTML = '<div class="empty-state"><p class="text-caption">لا توجد طلبات بعد</p><button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="showPage(\'new-order\')">طلب جديد</button></div>';
    return;
  }

  list.innerHTML = orders.map(o => {
    const nextStatus = getNextStatus(o.status);
    const overdueBadge = isOverdue(o) ? '<span class="text-xs text-red-500 font-bold">⚠ متأخر</span>' : '';

    return `
      <div class="order-card">
        <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
          <div class="min-w-0 flex-1">
            <div class="flex items-center gap-2 flex-wrap mb-1">
              <h3 class="font-bold">${o.customerName}</h3>
              <span class="badge badge-${o.status}">${STATUS_LABELS[o.status]}</span>
              ${overdueBadge}
            </div>
            ${o.customerPhone ? `<p class="text-caption" style="margin:4px 0">${o.customerPhone}</p>` : ''}
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
              ${o.productType ? `<span class="badge badge-new">${o.productType}</span>` : ''}
              <span class="badge" style="background:var(--gray-100);color:var(--text-secondary)">${o.paperType}</span>
              <span class="badge" style="background:var(--gray-100);color:var(--text-secondary)">${o.paperSize}</span>
              <span class="badge" style="background:var(--gray-100);color:var(--text-secondary)">${o.printType}</span>
              <span class="badge" style="background:var(--gray-100);color:var(--text-secondary)">${o.notebooks || o.quantity} دفتر × ${o.sheetsPerBook || '—'} ورقة</span>
            </div>
            ${o.notes ? `<p class="text-caption" style="margin-top:8px;font-style:italic">"${o.notes}"</p>` : ''}
            <div class="text-caption" style="margin-top:8px;display:flex;flex-wrap:wrap;gap:12px">
              <span>${formatDateTime(o.createdAt)}</span>
              ${o.dueDate ? `<span>التسليم: ${formatDate(o.dueDate)}</span>` : ''}
            </div>
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;flex-shrink:0">
            <p class="text-number" style="font-size:1.125rem">${formatMoney(o.total)}</p>
            <div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:flex-end">
              ${nextStatus ? `<button onclick="advanceStatus('${o.id}')" class="btn btn-primary btn-sm">← ${STATUS_LABELS[nextStatus]}</button>` : ''}
              ${o.status !== 'cancelled' && o.status !== 'delivered' ? `<button onclick="updateStatus('${o.id}', 'cancelled')" class="btn btn-secondary btn-sm" style="color:var(--red)">إلغاء</button>` : ''}
              <button onclick="showInvoice('${o.id}')" class="btn btn-secondary btn-sm">فاتورة</button>
              <button onclick="deleteOrder('${o.id}')" class="btn btn-ghost btn-sm">حذف</button>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function getNextStatus(current) {
  const idx = STATUS_FLOW.indexOf(current);
  if (idx === -1 || idx >= STATUS_FLOW.length - 1) return null;
  return STATUS_FLOW[idx + 1];
}

function advanceStatus(id) {
  const orders = getOrders();
  const o = orders.find(x => x.id === id);
  if (!o) return;
  const next = getNextStatus(o.status);
  if (!next) return;
  o.status = next;
  if (next === 'delivered') {
    o.completedAt = new Date().toISOString();
    deductInventory(o);
  }
  saveOrders(orders);
  renderOrders();
  showToast(`تم نقل الطلب إلى: ${STATUS_LABELS[next]}`);
  updateNotifBadge();
}

function updateStatus(id, status) {
  const orders = getOrders();
  const o = orders.find(x => x.id === id);
  if (!o) return;
  o.status = status;
  if (status === 'delivered') {
    o.completedAt = new Date().toISOString();
    deductInventory(o);
  }
  saveOrders(orders);
  renderOrders();
  showToast('تم تحديث الحالة');
  updateNotifBadge();
}

function deleteOrder(id) {
  if (!confirm('هل أنت متأكد من حذف هذا الطلب؟')) return;
  saveOrders(getOrders().filter(o => o.id !== id));
  renderOrders();
  showToast('تم الحذف');
}

function deductInventory(order) {
  const inv = getInventory();
  const match = inv.find(i => i.name.includes(order.paperType) || i.name.includes(order.paperSize));
  if (match && match.qty >= order.quantity) {
    match.qty -= order.quantity;
    saveInventory(inv);
  }
}

function resetForm() {
  document.getElementById('order-form').reset();
  document.getElementById('total-price').textContent = formatMoney(0);
  const sheetsEl = document.getElementById('calc-sheets');
  const costEl = document.getElementById('calc-paper-cost');
  if (sheetsEl) sheetsEl.textContent = '0 ورقة';
  if (costEl) costEl.textContent = formatMoney(0);
  const p1000 = document.getElementById('price-per-1000');
  const sell = document.getElementById('sell-price');
  if (p1000) { p1000.dataset.manual = ''; p1000.value = '15000'; }
  if (sell) { sell.dataset.manual = ''; sell.value = ''; }
  document.querySelectorAll('.option-card input').forEach(i => {
    if (i.name === 'sheets-per-book' && i.value === '100') i.checked = true;
    else if (i.name !== 'sheets-per-book') i.checked = false;
  });
  calcOrderTotals();
}

function populateCustomersDatalist() {
  const orders = getOrders();
  const names = [...new Set(orders.map(o => o.customerName))];
  document.getElementById('customers-list').innerHTML = names.map(n => `<option value="${n}">`).join('');
}

document.getElementById('notebooks')?.addEventListener('input', () => calcOrderTotals());
document.getElementById('price-per-1000')?.addEventListener('input', function() {
  this.dataset.manual = '1';
  calcOrderTotals();
});
document.getElementById('sell-price')?.addEventListener('input', function() {
  this.dataset.manual = '1';
  calcOrderTotals();
});

document.querySelectorAll('input[name="paper-type"], input[name="paper-size"], input[name="print-type"], input[name="product-type"], input[name="sheets-per-book"]').forEach(el => {
  el.addEventListener('change', () => {
    const p1000 = document.getElementById('price-per-1000');
    if (el.name === 'paper-type' && p1000) p1000.dataset.manual = '';
    const sell = document.getElementById('sell-price');
    if (sell) sell.dataset.manual = '';
    calcOrderTotals();
  });
});

document.getElementById('order-form')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const productType = document.querySelector('input[name="product-type"]:checked')?.value;
  const paperType = document.querySelector('input[name="paper-type"]:checked')?.value;
  const paperSize = document.querySelector('input[name="paper-size"]:checked')?.value;
  const printType = document.querySelector('input[name="print-type"]:checked')?.value;
  const sheetsPerBook = parseInt(document.querySelector('input[name="sheets-per-book"]:checked')?.value) || 100;
  if (!productType) {
    showToast('يرجى اختيار نوع الخدمة أو المنتج');
    return;
  }
  // خدمات التصميم والختم لا تتطلب ورقاً بالضرورة
  const noPaperNeeded = ['تصميم جرافيك', 'ختم وخدمات إدارية'].includes(productType);
  if (!noPaperNeeded && (!paperType || !paperSize || !printType)) {
    showToast('يرجى اختيار نوع الورق والمقاس ونوع الطباعة');
    return;
  }

  const calc = calcOrderTotals();
  const order = {
    id: generateId(),
    customerName: document.getElementById('customer-name').value.trim(),
    customerPhone: document.getElementById('customer-phone').value.trim(),
    productType,
    paperType: paperType || '—',
    paperSize: paperSize || '—',
    printType: printType || '—',
    notebooks: calc.notebooks,
    sheetsPerBook: calc.sheetsPerBook,
    quantity: calc.totalSheets, // total sheets for inventory
    pricePer1000: parseFloat(document.getElementById('price-per-1000').value) || 0,
    paperCost: Math.round(calc.paperCost),
    total: Math.round(calc.sellPrice),
    dueDate: document.getElementById('due-date').value || null,
    notes: document.getElementById('notes').value.trim(),
    status: 'new',
    createdAt: new Date().toISOString(),
    completedAt: null
  };

  const orders = getOrders();
  orders.push(order);
  saveOrders(orders);
  resetForm();
  showToast('تم حفظ الطلب بنجاح ✓');
  showPage('orders');
});

let editingInvId = null;

function renderInventory() {
  const inv = getInventory();
  const list = document.getElementById('inventory-list');
  if (!list) return;

  if (!inv.length) {
    list.innerHTML = '<div class="empty-state"><p class="text-caption">لم يتم إضافة مخزون بعد</p><button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="openInventoryModal()">إضافة صنف</button></div>';
    return;
  }

  list.innerHTML = inv.map(i => {
    const low = i.qty <= i.minQty;
    return `
      <div class="inv-item ${low ? 'low-stock' : ''}">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
          <div>
            <div style="font-weight:700">${i.name}</div>
            ${low ? '<span class="text-caption" style="color:var(--amber);font-weight:600">مخزون منخفض</span>' : ''}
          </div>
          <div style="display:flex;gap:6px">
            <button onclick="editInventory('${i.id}')" class="btn btn-secondary btn-sm">تعديل</button>
            <button onclick="deleteInventory('${i.id}')" class="btn btn-ghost btn-sm" style="color:var(--red)">حذف</button>
          </div>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:flex-end">
          <div>
            <div class="text-number" style="font-size:1.5rem">${i.qty}</div>
            <div class="text-caption">${i.unit} · الحد الأدنى: ${i.minQty}</div>
          </div>
          <div style="display:flex;gap:6px">
            <button onclick="adjustInventory('${i.id}', -10)" class="btn btn-secondary btn-sm" style="width:36px;padding:8px">−</button>
            <button onclick="adjustInventory('${i.id}', 10)" class="btn btn-primary btn-sm" style="width:36px;padding:8px">+</button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function openInventoryModal(id = null) {
  editingInvId = id;
  document.getElementById('inv-modal-title').textContent = id ? 'تعديل صنف' : 'إضافة صنف للمخزون';
  if (id) {
    const item = getInventory().find(i => i.id === id);
    if (item) {
      document.getElementById('inv-name').value = item.name;
      document.getElementById('inv-qty').value = item.qty;
      document.getElementById('inv-min').value = item.minQty;
      document.getElementById('inv-unit').value = item.unit;
    }
  } else {
    document.getElementById('inv-name').value = '';
    document.getElementById('inv-qty').value = 0;
    document.getElementById('inv-min').value = 50;
    document.getElementById('inv-unit').value = 'ورقة';
  }
  document.getElementById('inventory-modal').classList.add('show');
  document.body.style.overflow = 'hidden';
}

function closeInventoryModal() {
  document.getElementById('inventory-modal').classList.remove('show');
  document.body.style.overflow = '';
  editingInvId = null;
}

function saveInventoryItem() {
  const name = document.getElementById('inv-name').value.trim();
  if (!name) { showToast('أدخل اسم الصنف'); return; }
  const qty = parseInt(document.getElementById('inv-qty').value) || 0;
  const minQty = parseInt(document.getElementById('inv-min').value) || 0;
  const unit = document.getElementById('inv-unit').value;

  let inv = getInventory();
  if (editingInvId) {
    const item = inv.find(i => i.id === editingInvId);
    if (item) { item.name = name; item.qty = qty; item.minQty = minQty; item.unit = unit; }
  } else {
    inv.push({ id: generateId(), name, qty, minQty, unit });
  }
  saveInventory(inv);
  closeInventoryModal();
  renderInventory();
  showToast('تم حفظ الصنف');
}

function editInventory(id) { openInventoryModal(id); }

function deleteInventory(id) {
  if (!confirm('حذف هذا الصنف؟')) return;
  saveInventory(getInventory().filter(i => i.id !== id));
  renderInventory();
  showToast('تم الحذف');
}

function adjustInventory(id, delta) {
  const inv = getInventory();
  const item = inv.find(i => i.id === id);
  if (item) {
    item.qty = Math.max(0, item.qty + delta);
    saveInventory(inv);
    renderInventory();
  }
}

function getCustomers() {
  const orders = getOrders();
  const map = {};
  orders.forEach(o => {
    const key = o.customerName.trim().toLowerCase();
    if (!map[key]) {
      map[key] = { name: o.customerName, phone: o.customerPhone || '', orders: [], totalSpent: 0, lastOrder: null };
    }
    map[key].orders.push(o);
    if (o.status === 'delivered') map[key].totalSpent += o.total || 0;
    if (!map[key].lastOrder || new Date(o.createdAt) > new Date(map[key].lastOrder)) {
      map[key].lastOrder = o.createdAt;
      if (o.customerPhone) map[key].phone = o.customerPhone;
    }
  });
  return Object.values(map).sort((a, b) => new Date(b.lastOrder) - new Date(a.lastOrder));
}

function renderCustomers() {
  let customers = getCustomers();
  const list = document.getElementById('customers-list-view');
  if (!list) return;

  if (!customers.length) {
    list.innerHTML = '<div class="empty-state"><p class="text-caption">لا يوجد عملاء بعد</p></div>';
    return;
  }

  list.innerHTML = customers.map(c => `
    <div class="order-card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">
        <div>
          <div style="font-weight:700">${c.name}</div>
          ${c.phone ? `<p class="text-caption" style="margin-top:2px">${c.phone}</p>` : ''}
          <p class="text-caption" style="margin-top:4px">آخر طلب: ${formatDate(c.lastOrder)} · ${c.orders.length} طلب</p>
        </div>
        <div style="text-align:left">
          <div class="text-number" style="color:var(--success)">${formatMoney(c.totalSpent)}</div>
          <p class="text-caption">إجمالي المشتريات</p>
        </div>
      </div>
    </div>
  `).join('');
}

function updateReports() {
  const orders = getOrders().filter(o => o.status === 'delivered');
  const rev = orders.reduce((s, o) => s + (o.total || 0), 0);
  const cost = orders.reduce((s, o) => s + (o.paperCost || 0), 0);
  document.getElementById('report-revenue').textContent = formatMoney(rev);
  document.getElementById('report-cost').textContent = formatMoney(cost);
  document.getElementById('report-profit').textContent = formatMoney(rev - cost);
  const ro = document.getElementById('report-orders');
  if (ro) ro.textContent = orders.length;

  const months = {};
  const now = new Date();
  for (let i = 11; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    months[key] = { rev: 0, cost: 0 };
  }
  orders.forEach(o => {
    const d = new Date(o.completedAt || o.createdAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    if (months[key]) {
      months[key].rev += o.total || 0;
      months[key].cost += o.paperCost || 0;
    }
  });
  const monthNames = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  const labels = Object.keys(months).map(k => monthNames[parseInt(k.split('-')[1]) - 1]);

  const ctx = document.getElementById('reportChart');
  if (reportChart) reportChart.destroy();
  reportChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        { label: 'الإيرادات', data: Object.values(months).map(m => m.rev), borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.1)', fill: true, tension: 0.3 },
        { label: 'التكاليف', data: Object.values(months).map(m => m.cost), borderColor: '#ef4444', backgroundColor: 'rgba(239,68,68,0.1)', fill: true, tension: 0.3 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { font: { family: 'IBM Plex Sans Arabic' } } } },
      scales: { y: { beginAtZero: true, ticks: { callback: v => new Intl.NumberFormat('ar-SD', { notation: 'compact' }).format(v) } } }
    }
  });
}

function showInvoice(id) {
  const o = getOrders().find(x => x.id === id);
  if (!o) return;
  const s = getSettings();
  document.getElementById('invoice-content').innerHTML = `
    <div class="text-center mb-6 border-b pb-4">
      <h2 class="text-xl font-bold">${s.company || 'مطبعة المداد'}</h2>
      ${s.phone ? `<p class="text-sm text-slate-500">${s.phone}</p>` : ''}
      ${s.address ? `<p class="text-sm text-slate-500">${s.address}</p>` : ''}
      <p class="text-sm font-medium mt-2">فاتورة طلب</p>
    </div>
    <div class="grid grid-cols-2 gap-4 text-sm mb-4">
      <div>
        <p class="text-slate-500">العميل</p>
        <p class="font-bold">${o.customerName}</p>
        ${o.customerPhone ? `<p>${o.customerPhone}</p>` : ''}
      </div>
      <div class="text-left">
        <p class="text-slate-500">رقم الطلب</p>
        <p class="font-mono text-xs">${o.id}</p>
        <p class="text-slate-500 mt-1">التاريخ</p>
        <p>${formatDate(o.createdAt)}</p>
      </div>
    </div>
    <table class="w-full text-sm mb-4">
      <thead>
        <tr class="border-b">
          <th class="py-2 text-right">الوصف</th>
          <th class="py-2 text-center">الكمية</th>
          <th class="py-2 text-left">المبلغ</th>
        </tr>
      </thead>
      <tbody>
        <tr class="border-b">
          <td class="py-3">
            <p class="font-medium">${o.productType || ''} — ${o.paperType} ${o.paperSize}</p>
            <p class="text-xs text-slate-500">${o.printType} · ${o.notebooks || 0} دفتر × ${o.sheetsPerBook || 0} ورقة</p>
          </td>
          <td class="py-3 text-center">${o.notebooks || o.quantity}</td>
          <td class="py-3 text-left font-medium">${formatMoney(o.total)}</td>
        </tr>
      </tbody>
    </table>
    <div class="flex justify-between items-center border-t pt-4">
      <span class="font-bold">الإجمالي</span>
      <span class="text-xl font-bold text-primary-600">${formatMoney(o.total)}</span>
    </div>
    ${o.notes ? `<p class="text-xs text-slate-500 mt-4">ملاحظات: ${o.notes}</p>` : ''}
    <p class="text-center text-xs text-slate-400 mt-6">شكراً لتعاملكم معنا</p>
  `;
  document.getElementById('invoice-modal').classList.add('show');
  document.body.style.overflow = 'hidden';
}

function closeInvoice() {
  document.getElementById('invoice-modal').classList.remove('show');
  document.body.style.overflow = '';
}

function loadSettingsUI() {
  const s = getSettings();
  document.getElementById('setting-company').value = s.company || '';
  document.getElementById('setting-phone').value = s.phone || '';
  document.getElementById('setting-address').value = s.address || '';

  const prices = s.pricePer1000 || DEFAULT_PRICE_PER_1000;
  const grid = document.getElementById('pricing-grid');
  let html = '';
  for (const [type, price] of Object.entries(prices)) {
    html += `
      <div>
        <label class="block text-xs text-slate-500 mb-0.5">${type} — سعر الألف</label>
        <input type="number" data-type="${type}" value="${price}" class="form-input !py-1.5 text-sm pricing-input" min="0">
      </div>
    `;
  }
  html += `
    <div class="sm:col-span-2">
      <label class="block text-xs text-slate-500 mb-0.5">هامش الربح (مثال 1.5 = ربح 50%)</label>
      <input type="number" id="setting-markup" value="${s.markup || DEFAULT_MARKUP}" step="0.1" min="1" class="form-input !py-1.5 text-sm">
    </div>
  `;
  grid.innerHTML = html;
}

function saveSettings() {
  const s = getSettings();
  s.company = document.getElementById('setting-company').value.trim();
  s.phone = document.getElementById('setting-phone').value.trim();
  s.address = document.getElementById('setting-address').value.trim();

  const pricePer1000 = {};
  document.querySelectorAll('.pricing-input').forEach(inp => {
    const type = inp.dataset.type;
    if (type) pricePer1000[type] = parseFloat(inp.value) || 0;
  });
  s.pricePer1000 = pricePer1000;
  const markupEl = document.getElementById('setting-markup');
  if (markupEl) s.markup = parseFloat(markupEl.value) || DEFAULT_MARKUP;
  saveSettingsData(s);
  showToast('تم حفظ الإعدادات ✓');
}

function clearAllData() {
  if (!confirm('هل أنت متأكد؟ سيتم حذف كل الطلبات والمخزون والإعدادات!')) return;
  if (!confirm('تأكيد نهائي: لا يمكن التراجع!')) return;
  localStorage.removeItem(KEYS.orders);
  localStorage.removeItem(KEYS.inventory);
  localStorage.removeItem(KEYS.settings);
  showToast('تم مسح كل البيانات');
  showPage('dashboard');
}

function exportData() {
  const data = {
    orders: getOrders(),
    inventory: getInventory(),
    settings: getSettings(),
    exportedAt: new Date().toISOString()
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `madad-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('تم تصدير البيانات');
}

function importData(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const data = JSON.parse(ev.target.result);
      if (data.orders) saveOrders(data.orders);
      if (data.inventory) saveInventory(data.inventory);
      if (data.settings) saveSettingsData(data.settings);
      showToast('تم استيراد البيانات بنجاح');
      showPage('dashboard');
    } catch {
      showToast('ملف غير صالح');
    }
  };
  reader.readAsText(file);
  e.target.value = '';
}

function getNotifications() {
  const orders = getOrders();
  const inv = getInventory();
  const notifs = [];
  orders.filter(isOverdue).forEach(o => {
    notifs.push({ type: 'overdue', text: `طلب متأخر: ${o.customerName}`, id: o.id });
  });
  orders.filter(o => o.status === 'ready').forEach(o => {
    notifs.push({ type: 'ready', text: `جاهز للتسليم: ${o.customerName}`, id: o.id });
  });
  inv.filter(i => i.qty <= i.minQty).forEach(i => {
    notifs.push({ type: 'stock', text: `مخزون منخفض: ${i.name} (${i.qty})`, id: i.id });
  });
  return notifs;
}

function updateNotifBadge() {
  const notifs = getNotifications();
  const badge = document.getElementById('notif-badge');
  if (notifs.length) {
    badge.textContent = notifs.length;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

function toggleNotifications() {
  const panel = document.getElementById('notif-panel');
  panel.classList.toggle('hidden');
  if (!panel.classList.contains('hidden')) {
    const notifs = getNotifications();
    const list = document.getElementById('notif-list');
    if (!notifs.length) {
      list.innerHTML = '<p class="text-sm text-slate-400 text-center py-4">لا توجد تنبيهات</p>';
    } else {
      list.innerHTML = notifs.map(n => `
        <div class="px-3 py-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-dark-700 text-sm flex items-center gap-2">
          <span>${n.type === 'overdue' ? '🚨' : n.type === 'ready' ? '✅' : '📦'}</span>
          <span>${n.text}</span>
        </div>
      `).join('');
    }
  }
}

document.addEventListener('click', (e) => {
  const panel = document.getElementById('notif-panel');
  const btn = document.getElementById('notif-btn');
  if (panel && !panel.classList.contains('hidden') && !panel.contains(e.target) && btn && !btn.contains(e.target)) {
    panel.classList.add('hidden');
  }
});

let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  if (!localStorage.getItem('install_dismissed')) {
    document.getElementById('install-banner').classList.remove('hidden');
  }
});
document.getElementById('install-btn')?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  document.getElementById('install-banner').classList.add('hidden');
});
document.getElementById('dismiss-install')?.addEventListener('click', () => {
  document.getElementById('install-banner').classList.add('hidden');
  localStorage.setItem('install_dismissed', '1');
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  if (!getInventory().length) {
    saveInventory([
      { id: 'inv1', name: 'أوفست A4', qty: 5000, minQty: 500, unit: 'ورقة' },
      { id: 'inv2', name: 'كوشيه لامع A3', qty: 1000, minQty: 200, unit: 'ورقة' },
      { id: 'inv3', name: 'كرتون A4', qty: 300, minQty: 50, unit: 'ورقة' }
    ]);
  }
  showPage('dashboard');
});


let currentOrderFilter = 'all';
function filterOrders(status, btn) {
  currentOrderFilter = status;
  document.querySelectorAll('#order-filters .btn').forEach(b => b.classList.remove('active-filter'));
  if (btn) btn.classList.add('active-filter');
  renderOrders();
}
